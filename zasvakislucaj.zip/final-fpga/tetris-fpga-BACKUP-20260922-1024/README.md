# Tetris na FPGA ploči DE0-CV

Računarski sistem sa sopstvenim RISC-V procesorom, grafikom u SDRAM-u, VGA izlazom,
PS/2 tastaturom i mišem. Kao demonstraciona igra radi Tetris.

Ceo hardver je urađen **šematski** (`.bdf`); jedini VHDL su komponente koje pravi
ugrađeni MegaWizard (brojači, komparatori, multiplekseri, memorije, PLL).

Projekat: `Tetris.qpf`, vrh sistema: `Tetris.bdf`, ploča: DE0-CV (Cyclone V 5CEBA4F23C7),
alat: Quartus II 13.1.

## Kako se pokreće

1. `TetrisProgram/build.sh` prevodi igru i upisuje je u `Memory/rom_init.mif`
   (potreban je RISC-V prevodilac, `riscv64-linux-gnu-gcc` ili `riscv64-unknown-elf-gcc`).
2. U Quartusu: Processing → Start Compilation.
3. Programator: `output_files/Tetris.sof` na ploču.
4. Tastatura ili miš idu u PS/2 priključak — ploča ima samo jedan, pa **prekidač SW9
   bira koji je uređaj utaknut**: dole (0) = tastatura, gore (1) = miš. Izabrani režim
   se vidi na LEDR6.

Ako se na HEX displeju ništa ne menja, a slika je crna, ploča nije dobila program —
treba ponoviti korak 1 pa kompilaciju.

## Miš

Ploča DE0-CV ima jedan PS/2 priključak. Oba kontrolera (tastatura i miš) slušaju iste
linije, a `SW9` uključuje samo onaj koji treba, da onaj drugi ne bi čitao tuđe bajtove:

| SW9 | Šta radi |
|---|---|
| dole (0) | tastatura radi, kontroler miša je ugašen i pušta linije |
| gore (1) | miš radi, dekoder tastature je isključen |

Postupak:

1. Utakni miša u PS/2 priključak i podigni **SW9**. Zasvetleće **LEDR6**.
2. Ako miš nije reagovao (na primer, utaknut je posle podizanja prekidača), pritisni
   **KEY0** — kontroler tada ponovo pošalje naredbu „šalji podatke“ (`0xF4`).
3. Provera na LED-ovima: **LEDR8** zasvetli kada miš primi naredbu, **LEDR7** menja
   stanje na svaki paket (pomeri miša), a **LEDR0/LEDR1/LEDR2** su levi/desni/srednji
   taster.

Mora biti pravi PS/2 miš ili USB miš koji podržava PS/2 uz pasivni (zeleni) adapter.

Ako nabaviš PS/2 Y-razdelnik, tastatura i miš mogu da rade istovremeno: u `Tetris.bdf`
treba kontroler miša vratiti na `PS2_CLK2`/`PS2_DAT2` (drugi par), a `SW9` i kapiju nad
`KB_INTR` izbaciti.

## Upravljanje

| Taster | Radnja |
|---|---|
| strelica levo / desno | pomeranje tetromine |
| strelica dole | brži pad |
| Z | okretanje |
| strelica gore | odlaganje tetromine (hold) |
| razmak | trenutni pad |
| P | pauza |
| T ili levi taster miša | sledeća tema boja (desni taster miša — prethodna) |
| Z ili razmak posle kraja igre | nova igra |
| KEY0 | reset celog sistema (i ponovna prijava miša) |
| SW9 | dole tastatura, gore miš |

Broj poena se ispisuje na HEX displeju.

Reset tasterom KEY0 ponovo pokreće i kontroler miša, pa se njime miš može ponovo
prijaviti ako je utaknut posle paljenja ploče.

## Delovi sistema

| Folder | Šta sadrži |
|---|---|
| `CPU/` | procesor: putanja podataka, mikroprogramska upravljačka jedinica, adapter magistrale |
| `Memory/` | ROM, RAM, memorijski preslikan U/I, grafički crtač, kontroler i arbitar SDRAM-a |
| `GPU/` | VGA kontroler 800×600 (`vga`, vremena daje `vga_timing`); slika 400×300 se uvećava dvostruko |
| `KbController/` | `kb_ps2` prima PS/2 kodove, `kb_keys` od njih pravi bit-mapu pritisnutih tastera |
| `MouseController/` | kontroler miša (šalje 0xF4, prima pakete od tri bajta) |
| `Components/` | zajedničke komponente: displej, kontroler prekida, registri, multiplekseri |
| `TetrisProgram/` | program igre u C-u i alat koji od njega pravi `.mif` |

Detaljan opis procesora, mape adresa i veza među blokovima je u
[`RV32_specifikacija.md`](RV32_specifikacija.md).

## Mapa adresa

| Opseg | Šta je |
|---|---|
| `0x00000000` | ROM sa programom (8192 reči) |
| `0x04000000` | RAM (8192 reči, vrh steka `0x04008000`) |
| `0x08000000` | periferije (grafika, tastatura, miš, prekidi, displej, tajmer) |
| `0x0C000000` | SDRAM: dva bafera slike 400×300, piksel je `(bafer<<20) | (y<<10) | x` |

## Registri periferija (`0x08000000 + pomeraj`)

| Pomeraj | Registar |
|---|---|
| `0x00` | stanje: bit 0 vertikalna sinhronizacija, bit 1 grafika radi |
| `0x04` | upravljanje slikom: bit 0 zamena bafera, bit 1 crtanje u prikazani bafer |
| `0x08`–`0x1C` | X0, Y0, X1, Y1, boja, naredba (1 tačka, 2 linija, 3 pun pravougaonik) |
| `0x20` | bit-mapa tastera |
| `0x24` | miš: bitovi 2..0 tasteri, 10..3 pomeraj po x, 18..11 pomeraj po y, 19 se menja na svaki paket |
| `0x28` / `0x2C` | zastavice prekida / brisanje zastavica (bit 0 tastatura, bit 1 nova slika) |
| `0x30` | šest cifara za HEX displej |
| `0x34` | tajmer, broji milisekunde |
