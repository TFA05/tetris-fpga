mux4_5_inst : mux4_5 PORT MAP (
		data0x	 => data0x_sig,
		data1x	 => data1x_sig,
		data2x	 => data2x_sig,
		data3x	 => data3x_sig,
		sel	 => sel_sig,
		result	 => result_sig
	);
