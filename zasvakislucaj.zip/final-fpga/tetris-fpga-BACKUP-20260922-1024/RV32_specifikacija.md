# RV32 procesor: specifikacija i stanje izrade

## 1. Skup instrukcija (podskup RV32I + prilagođene)

Instrukcije su široke 32 bita i poravnate na 4 bajta. Procesor ima 32 registra, a `x0` je uvek 0.

| Grupa | Instrukcije | opcode | funct3 / funct7 |
|---|---|---|---|
| U | LUI, AUIPC | 0110111, 0010111 | |
| J | JAL | 1101111 | |
| I | JALR | 1100111 | 000 |
| B | BEQ, BNE, BLT, BGE, BLTU, BGEU | 1100011 | 000, 001, 100, 101, 110, 111 |
| Load | LW | 0000011 | 010 |
| Store | SW | 0100011 | 010 |
| OP-IMM | ADDI, SLTI, SLTIU, XORI, ORI, ANDI | 0010011 | 000, 010, 011, 100, 110, 111 |
| OP-IMM | SLLI, SRLI, SRAI | 0010011 | 001/0000000, 101/0000000, 101/0100000 |
| OP | ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND | 0110011 | standardni RV32I |
| custom-0 | DRAWP, DRAWL, DRAWR `rd, rs1, rs2` | 0001011 | 001, 010, 011 (= GFX_CMD) |
| SYSTEM | MRET, CSRSI mstatus,8, CSRCI mstatus,8 | 1110011 | 0x30200073, 0x30046073, 0x30047073 |

Instrukcije za crtanje:
- `rs1 = (x0 << 16) | y0` i `rs2 = (x1 << 16) | y1`.
- `rd` se **čita** i sadrži boju (RGB444). U `rd` se ništa ne upisuje.
- Kod DRAWP se koriste samo `x0` i `y0`.

Pošto `SLTIU`, `BLTU` i `BGEU` koriste isti komparator bez znaka kao `SLTU`, dobijaju se bez dodatnog hardvera.

## 2. Interfejs prema arbitru

| Signal | Smer | Opis |
|---|---|---|
| `ADDR[31..0]` | CPU → | bajtovska adresa |
| `DATA_W[31..0]` | CPU → | podatak za upis |
| `RD`, `WR` | CPU → | zahtev za čitanje ili upis |
| `DATA_R[31..0]` | → CPU | pročitani podatak, važi dok je READY=1 |
| `READY` | → CPU | ciklus je završen, traje 1 takt |
| `IRQ` | → CPU | zahtev za prekid |

- Procesor drži `ADDR`, `DATA_W` i `RD`/`WR` nepromenjene dok ne dobije `READY`.
- Ako posle `READY` signal `RD` ili `WR` ostane aktivan, a adresa se promeni, to je **novi** ciklus. Tako rade upisi jedan za drugim kod DRAW instrukcija.

## 3. Organizacija: višeciklusni procesor

### Registri
| Registar | Upis | Sadržaj |
|---|---|---|
| PC | `PC_WE` | adresa sledeće instrukcije (posle FETCH je PC+4) |
| OLD_PC | `IR_WE` | adresa tekuće instrukcije (za AUIPC, JAL i grananja) |
| IR | `IR_WE` | tekuća instrukcija |
| EPC | `EPC_WE` | povratna adresa iz prekida |
| RF 32×32 | `RF_WE` | registri (2× M10K) |

Blok-memorija M10K ima registrovanu adresu i neregistrovan izlaz, pa ta adresa služi kao registri A i B. Vrednosti rs1 i rs2 su spremne jedan takt posle stanja DECODE. Pri čitanju i upisu iste adrese u istom taktu čita se stara vrednost (OLD_DATA).

### Upravljački signali putanje podataka (šeme `pc`, `instruction`, `register_file`, `imm_gen`, `alu_src_mux`, `alu`, `pc_next`, `data_mem`)

| Signal | Vrednosti |
|---|---|
| `A_SEL[1..0]` | 0 rs1, 1 OLD_PC, 2 PC, 3 nula |
| `B_SEL[1..0]` | 0 rs2, 1 IMM, 2 konstanta 4, 3 nula |
| `IMM_SEL[2..0]` | 0 I, 1 S, 2 B, 3 U, 4 J |
| `ALU_FN` | 0 = sabiranje; 1 = operacija iz funct3/funct7 (ALT = IR[30] za OP, odnosno za SRAI) |
| `PC_SRC[1..0]` | 0 ALU & ~1, 1 EPC, 2 vektor prekida 0x10 |
| `WB_SEL[1..0]` | 0 ALU, 1 DATA_R, 2 PC (povratna adresa = OLD_PC+4) |
| `ADR_SEL[1..0]` | 0 PC, 1 ALU, 2 MMIO: `0x08000000 + MOFF*4` |
| `MOFF[2..0]` | 0 VGA_STATUS, 2 X0, 3 Y0, 4 X1, 5 Y1, 6 COLOR, 7 CMD |
| `WD_SEL[2..0]` | 0 rs2, 1 rs1[31..16], 2 rs1[15..0], 3 rs2[31..16], 4 rs2[15..0], 5 funct3 |
| `RS2_SEL` | 0 = drugi port za čitanje adresiran sa rs2, 1 = sa rd (boja kod DRAW) |
| `PC_WE`, `IR_WE`, `EPC_WE`, `RF_WE` | dozvole upisa |

Izlazi putanje podataka: `ADDR`, `DATA_W`, `IR` (ide u upravljačku jedinicu) i `TAKEN` (uslov grananja po funct3).

## 4. Tabela stanja upravljačke jedinice

U tabeli su navedeni samo signali koji nisu 0. Oznaka „**čeka**“ znači da se ostaje u stanju dok je READY=0. Dozvole upisa označene sa `*` važe samo u taktu kada je READY=1.

| Stanje | Signali | Sledeće stanje |
|---|---|---|
| FETCH | RD, A=2, B=2, IR_WE*, PC_WE* | **čeka** → DECODE |
| DECODE | – | po opcode-u (nepoznat opcode → KRAJ) |
| EX_LUI | A=3, B=1, IMM=U, RF_WE | KRAJ |
| EX_AUIPC | A=1, B=1, IMM=U, RF_WE | KRAJ |
| EX_JAL | A=1, B=1, IMM=J, PC_WE, RF_WE, WB=2 | KRAJ |
| EX_JALR | A=0, B=1, IMM=I, PC_WE, RF_WE, WB=2 | KRAJ |
| EX_BR | A=1, B=1, IMM=B, PC_WE=TAKEN | KRAJ |
| EX_OP | ALU_FN, RF_WE | KRAJ |
| EX_OPIMM | ALU_FN, B=1, IMM=I, RF_WE | KRAJ |
| MEM_LW | B=1, IMM=I, ADR=1, RD, WB=1, RF_WE* | **čeka** → KRAJ |
| MEM_SW | B=1, IMM=S, ADR=1, WR | **čeka** → KRAJ |
| DR_POLL | ADR=2, MOFF=0, RD | ako je READY i DATA_R[1]=0 → DR_X0, inače DR_POLL |
| DR_X0 | ADR=2, MOFF=2, WD=1, WR | **čeka** → DR_Y0 |
| DR_Y0 | ADR=2, MOFF=3, WD=2, WR | **čeka** → DR_X1 |
| DR_X1 | ADR=2, MOFF=4, WD=3, WR | **čeka** → DR_Y1 |
| DR_Y1 | ADR=2, MOFF=5, WD=4, WR | **čeka** → DR_SW |
| DR_SW | RS2_SEL=1 (jedan takt da M10K preuzme adresu rd) | DR_COL |
| DR_COL | RS2_SEL=1, ADR=2, MOFF=6, WD=0, WR | **čeka** → DR_CMD |
| DR_CMD | ADR=2, MOFF=7, WD=5, WR | **čeka** → KRAJ |
| EX_MRET | PC_SRC=1, PC_WE, IE ← 1 | KRAJ |
| INT | EPC_WE, PC_SRC=2, PC_WE, IE ← 0 | FETCH |

**KRAJ** znači: ako je `IRQ=1` i `IE=1`, sledeće stanje je INT, a inače FETCH. `IE` je flip-flop u upravljačkoj jedinici (korak 7).

Trajanje instrukcije je FETCH (1 + čekanje memorije) + DECODE + EX, dakle 3 takta plus čekanje. LW i SW imaju još jedan pristup memoriji.

## 5. Šta je urađeno i provereno

Fajlovi su u folderu `CPU/`:
- **Komponente iz MegaWizarda:** `pc_register` (LPM_SHIFTREG kao registar sa enable i aclr), `alu_adder`, `alu_compare`, `alu_compare_u`, `alu_shift`, `alu_sra` (LPM_CLSHIFT), `alu_mux`, `alu_src_mux_ip`, `mux4_32`, `mux2_5`, `mux4_5`, `mux8_1` (LPM_MUX), `reg_mem_a` (RAM: 2-PORT), `control_rom` (ROM: 1-PORT).
- **Šeme:** `tetris_cpu.bdf` (vrh), `instruction_decoder.bdf` (upravljačka jedinica), `pc.bdf`, `instruction.bdf`, `register_file.bdf`, `imm_gen.bdf`, `alu_src_mux.bdf`, `alu.bdf`, `pc_next.bdf`, `data_mem.bdf`; mikrokod `control_rom.mif`.

Provera:
- Quartus 13.1 Analysis & Synthesis: 0 grešaka, 0 upozorenja.
- Puna kompilacija za 5CEBA4F23C7: 619 ALM-ova, 128 registara, na 50 MHz rezerva 4,7 ns (oko 65 MHz).
- Simulacija u ModelSim-u, sa modelom upravljačke jedinice po tabeli iz odeljka 4: program od 81 instrukcije pokriva sve instrukcije osim MRET, uz memoriju koja kasni 3 takta. Svih 31 registara i svih 12 MMIO upisa za DRAWR/DRAWP se poklapaju sa referentnim simulatorom.

Napomena o šemama: konstantna nula je mreža `NULA`, koju pokreću dva GND simbola (`NULA[31..16]` i `NULA[15..0]`). Quartus konvertor u VHDL ne prepoznaje jedan GND na celoj magistrali koja se koristi u delovima.

## 6. Upravljačka jedinica (korak 4): `instruction_decoder.bdf`

- **Mikrokod ROM** `control_rom` (ROM: 1-PORT, 32 × 45 bita, `CPU/control_rom.mif`). Adresa ROM-a je **sledeće stanje**. M10K registruje adresu, pa taj registar služi i kao registar stanja: izlaz ROM-a daje kontrolne signale tekućeg stanja, bez kašnjenja od jednog takta.
- **Kodovi stanja:** stanja izvršavanja imaju kod jednak `opcode[6..2]`, pa je dispečovanje u DECODE samo `IR[6..2]` doveden na mux sledećeg stanja.

| Kod | Stanje | Kod | Stanje | Kod | Stanje |
|---|---|---|---|---|---|
| 0 | LW | 8 | SW | 16 | INT |
| 1 | FETCH (posle reseta) | 9 | DR_X1 | 24 | BR |
| 2 | DR_POLL (DRAW) | 10 | DR_Y1 | 25 | JALR |
| 3 | DECODE | 11 | DR_SW | 27 | JAL |
| 4 | OPIMM | 12 | OP | 28 | SYS (MRET, CSRSI, CSRCI) |
| 5 | AUIPC | 13 | LUI | ostali | nepoznat opcode → KRAJ |
| 6 | DR_X0 | 14 | DR_COL | | |
| 7 | DR_Y0 | 15 | DR_CMD | | |

- **Polja mikrokoda:** IR_WE[0], PC_WE[1], PC_BR[2], RF_WE[3], EPC_WE[4], GATE[5], RD[6], WR[7], RS2_SEL[8], ALU_FN[9], IMM[12..10], A[14..13], B[16..15], PC_SRC[18..17], WB[20..19], ADR[22..21], MOFF[25..23], WD[28..26], WAIT[29], POLL[30], MODE[32..31] (0 NEXT, 1 IR[6..2], 2 KRAJ), NEXT[37..33], CUR[42..38], SYSOP[43], IE_CLR[44].
- **Logika van ROM-a:**
  - `RDYOK = !GATE | READY`
  - `IR_WE`, `RF_WE` i deo `PC_WE` se množe sa RDYOK
  - `PC_WE = PC_WE·RDYOK + PC_BR·TAKEN + SYSOP·!IR[14]`
  - `STAY = WAIT·!READY + POLL·BUSY`, gde je `BUSY = DATA_R[1]`
  - `KRAJ = IRQ·IE ? INT(16) : FETCH(1)`
  - dok traje RESET, adresa ROM-a je FETCH (1)

## 7. Reset i prekidi (koraci 5 i 7): `tetris_cpu.bdf`

- **Reset:** `RESET_IN` (aktivan na 1, npr. `!KEY0 | !pll_locked`) se asinhrono postavlja, a sinhrono otpušta kroz 2 DFF-a. Resetuje PC (na 0), IR, OLD_PC, EPC i IE, a upravljačka jedinica kreće od FETCH. **Takt mora da radi dok je reset aktivan.**
- **Prekidi:**
  - Proveravaju se na kraju svake instrukcije.
  - Kada je `IRQ=1` i `IE=1`: EPC ← PC (adresa sledeće instrukcije), PC ← **0x00000010**, IE ← 0.
  - `csrsi mstatus,8` (0x30046073) uključuje prekide, a `csrci mstatus,8` (0x30047073) ih isključuje.
  - `mret` (0x30200073) radi PC ← EPC i IE ← 1.
  - IRQ je **nivo**: rutina mora da obriše izvor (upis u IRQ_CLEAR, 0x0800002C) pre `mret`.
  - Procesor ne čuva registre sam, pa rutina mora da sačuva sve registre koje menja.

Raspored programa:
```
0x00: jal x0, main        # posle reseta
0x04-0x0C: nop
0x10: prekidna rutina ... mret
main: csrsi mstatus,8     # dozvola prekida kada je sve spremno
```

## 8. Provera celog procesora

- **Quartus 13.1:** sinteza bez grešaka i upozorenja. Puna kompilacija (`tetris_cpu` kao vrh): 580 ALM-ova, 129 registara, 3,5 Kbit blok-memorije, **Fmax ≈ 60 MHz** u najsporijem uglu. Preporučeni takt je 50 MHz.
- **ModelSim, `tetris_cpu` sa modelom memorije** (kašnjenje od 3 takta) i MMIO modelom: program od 97 instrukcija sa prekidnom rutinom i dva spoljna IRQ zahteva.
  - Svih 31 registara i svih 12 MMIO upisa (DRAWR/DRAWP) se poklapaju sa referentnim simulatorom.
  - Oba prekida su obrađena (brojač = 2, dva upisa u IRQ_CLEAR), a glavni program ih ne primećuje.
- Fajlovi procesora (`CPU/`) su dodati u `Tetris.qsf`, ali `tetris_cpu` još nije postavljen u `Tetris.bdf`. Čeka se arbitar.

## 9. Povezivanje sa arbitrom (za kolegu)

`tetris_cpu` pinovi:
- **Ulazi:** `CLK`, `RESET_IN`, `DATA_R[31..0]`, `READY`, `IRQ`
- **Izlazi:** `ADDR[31..0]`, `DATA_W[31..0]`, `RD`, `WR`, `PC_DBG[31..0]` (za debug, može ostati nepovezan)

Protokol je opisan u odeljku 2. Procesor pristupa samo celim rečima (LW/SW), a `ADDR[1..0]` je uvek 00.

## 10. Prvi test na ploči (korak 1): `Tetris.bdf`

Glavna šema povezuje:
- **PLL `sys_pll`:** `outclk_0` 50 MHz je sistemski takt, `outclk_1` 50 MHz sa pomerajem −3 ns ide na `DRAM_CLK`, `outclk_2` je takt piksela (danas 40 MHz za 800×600, u ovom koraku je bio 25 MHz).
- **Reset:** `RST_N = KEY[0] AND locked`, a `RESET_IN` procesora = `NOT RST_N`.
- **Procesor i memorija:** `tetris_cpu` → `bus_adapter` (`CPU/`) → `mem_top`. Adapter pretvara RD/WR, koji procesor drži do READY, u impuls RE/WE od jednog takta.
- **Displej:** `SEG7_DATA` → `seg7_display` (`Components/`, 6 × ROM `seg7_rom`) → `HEX0–HEX5`.
- **SDRAM:** `mem_top` ↔ svi `DRAM_*` pinovi.
- **Tastatura:** `kb_ps2` → `kb_keys` → `PS2_KEYS_LO[7..0]`.
- **Miš:** `mouse_ps2` na `PS2_CLK2`/`PS2_DAT2` (preko `OPNDRN` bafera) → `PS2_KEYS_HI`.
- **Slika:** VGA blok uzima piksele iz `PIX_DATA` i daje `LINE_REQ`, `LINE_Y`, `PIX_X`, `VSYNC` i pinove `VGA_*` (današnji blok je `GPU/vga.bdf`, odeljak 14).
- **Prekidi:** `irq_ctrl` → `IRQ` procesora i `IRQ_STATUS` u `mem_top`.
- **LED-ovi:** `LEDR[9]` = PLL zaključan, `LEDR[8]` = IE, `LEDR[7..5]` = PC[4..2], `LEDR[4..0]` = korak procesora.

**Testni program** (`Memory/rom_init.mif`): samotest ALU-a, grananja, LUI, RAM-a i poziva potprograma.
- Ako prođe, prikazuje **00600d** oko 2 s, a zatim brojač: HEX3..0 = TIMER/256, HEX5..4 = broj prolaza petlje / 4096.
- Ako neki test padne, prikazuje **bad00N** (N = broj testa).

**Provera:**
- Puna kompilacija: 726 ALM-ova, 439 registara, 98 pinova, rezerva na taktu od 50 MHz je +3,05 ns.
- Simulacija sklopa sa pravim `mem_top`: samotest prolazi, svaki zahtev dobija tačno jedan READY, a tajmer i petlja rade.

**Otvoreno (za kolegu koji radi memoriju):** refresh SDRAM-a je 1500 taktova = 30 µs na 50 MHz. SDRAM traži 7,8 µs, pa brojač treba smanjiti na najviše 390 pre testa slike (korak 2).

## 11. Arbitar SDRAM-a (put A): `Memory/sdram_arb.bdf`

Grafika (`gfx_engine`) i procesor dele jedan ulaz za upis u `sdram_ctrl`, pa arbitar odlučuje ko piše.

- **Odluku donosi postojeći blok `Arbitrator`** (BR0 = grafika, BR1 = procesor; procesor ima prednost jer stoji dok čeka).
- **Dodela se drži** u flip-flopovima `BUSY` i `OWN` dok ne stigne `WR_DONE`, pa se adresa i podatak ne menjaju usred upisa.
- **Muxevi:** `mx2x1_22` za adresu i `mx2x1_16` za podatak.
- **Potvrda:** `CPU_ACK = WR_DONE · SEL`, `GFX_DONE = WR_DONE · /SEL`.
- **`INIT_DONE`:** dok SDRAM nije inicijalizovan (oko 200 µs), zahtevi čekaju. Bez toga se upis procesora gubio, a procesor je dobijao potvrdu.

Izmene u `mem_top.bdf`: ulazi `sdram_ctrl`-a (`req_wr`, `req_addr`, `req_data`) i `wr_done` za `gfx_engine` idu preko arbitra, `sd_cpu_ack` dolazi iz arbitra, a `sd_bypass` je sada 0 (upis procesora u SDRAM više se ne preskače). Adresa piksela za procesor je `ADDR[23..2]`, a podatak `DATA_W[15..0]`, dakle piksel (bafer, x, y) je na `0x0C000000 + 4*((bafer<<20)|(y<<10)|x)`.

**Provera u simulaciji** (procesor + adapter + pravi `mem_top`):
- upis piksela sa `SW` daje tačno jednu WRITE komandu, na adresi banka 1, red 0x008, kolona 3, što je traženi piksel
- `DRAWR` pravougaonika 3×21 daje tačno 63 upisa
- upis procesora dok grafika još crta prolazi bez zastoja; ukupno 65 upisa
- sinteza `mem_top` sa arbitrom: 0 grešaka

## 12. Glavna šema po putu A (bez arbitracije na vrhu)

`Tetris.bdf` sada sadrži:

| Blok | Veza |
|---|---|
| `sys_pll` (50 / 50 sa −3 ns / takt piksela) | sistemski takt, `DRAM_CLK`, `CLK_VGA` |
| reset | `RST_N = KEY[0] AND locked`, `RESET_IN = NOT RST_N` |
| `tetris_cpu` → `bus_adapter` → `mem_top` | magistrala procesora |
| `mem_top` | ROM, RAM, MMIO, grafika, SDRAM i arbitar u sebi |
| *(mesto za VGA blok)* | radi kolega koji radi GPU; do tada su `LINE_REQ`, `LINE_Y`, `PIX_X` i `VSYNC` na nuli |
| `seg7_display` | `SEG7_DATA` → HEX0–HEX5 |
| `kb_ps2` → `kb_keys` | tastatura → `PS2_KEYS_LO[7..0]` |
| LED | `LEDR[9]` = PLL zaključan, `LEDR[8]` = reset otpušten, `LEDR[7..3]` = PC[4..0] |

Arbitracija na vrhu (`Arbitrator`, `mx2x1_22`, signali `cpu_req`/`gpu_req`/grant) je uklonjena, jer je arbitar sada u `mem_top`. Stari `GPU/GPU.bdf` je izbačen, a vremenski generator je `GPU/vga_timing.bdf` (odeljak 14).

### Prvi VGA blok (640×480, više nije u projektu)
U ovom koraku je slika bila 640×480 @ 60 Hz sa taktom piksela od 25 MHz, jedan na jedan,
bez uvećavanja. Simulacija sa pravim `mem_top` i modelom SDRAM-a je pokazala da se
pravougaonik nacrtan od x=100 do x=200 na ekranu vidi tačno tu, dakle da put piksela
nema pomeraj. Taj blok je zamenjen blokom `GPU/vga.bdf` (800×600, slika 400×300
uvećana dvostruko), jer na 640×480 jedan na jedan SDRAM jedva stiže da isporuči sliku,
a program ima manje vremena za crtanje. Opis je u odeljku 14.

Napomena iz tog testa važi i dalje: model SDRAM-a u simulaciji čita rafal linearno, a
pravi čip unutar rafala „obmotava“ kolone, pa se rezultati razilaze na granici kolone
(x=256).

## 13. Osvežavanje SDRAM-a

`Memory/refresh_cnt` (LPM_COUNTER) je preko wizarda promenjen sa modula **1500 na 384**:
- na 50 MHz to je jedan AUTO REFRESH na **7,68 µs**, a SDRAM na DE0-CV traži najviše 7,8125 µs (8192 reda za 64 ms)
- širina brojača ostaje 11 bita, pa je simbol nepromenjen i šema `sdram_ctrl` se ne dira

Provereno posle izmene: puna kompilacija bez grešaka (898 ALM, rezerva +3,0 / +17,2 ns), upis procesora i crtanje i dalje prolaze kroz arbitar, a slika i dalje izlazi na tačnim koordinatama. Uz brži refresh su se sada i oba pravougaonika u testu videla tačno (ranije se jedan video šire, zbog kasnijeg dohvata linije).


## 14. VGA blok: `GPU/vga.bdf`

Vremena daje `GPU/vga_timing.bdf` (ranije `Controller`): **800×600**, X broji do
1039, Y do 665, sinhronizacija je aktivna na jedinici, a `NEWR_SIG` javlja kraj vidljivog
dela linije. Takt piksela je 40 MHz (`outclk_2` iz PLL-a), pa je linija 26 µs, a kadar
17,3 ms (57,7 Hz).

Oko njega je veza prema `mem_top`:

| Signal | Smer | Značenje |
|---|---|---|
| `CLK_VGA` | ulaz | 40 MHz iz PLL-a |
| `RST_N` | ulaz | reset (aktivan na 0) |
| `PIX_DATA[15..0]` | ulaz | piksel iz bafera linije u `mem_top` (RGB444 u donjih 12 bita) |
| `LINE_REQ` | izlaz | zahtev za učitavanje vrste slike |
| `LINE_Y[8..0]` | izlaz | koja se vrsta traži |
| `PIX_X[9..0]` | izlaz | adresa piksela u baferu linije |
| `VSYNC` | izlaz | vertikalna sinhronizacija za `mem_top` |
| `VGA_R/G/B[3..0]`, `VGA_HS`, `VGA_VS` | izlaz | na pinove ploče |

**Slika u memoriji je 400×300 i uvećava se dvostruko** (`curY/2`, `curX/2`). Zbog toga
se nova vrsta traži samo na svakoj drugoj liniji, pa memorija ima duplo više vremena da
je donese — na 800×600 jedan na jedan SDRAM ne bi stigao da isporuči sliku.

### Broj vrste mora da stoji dok traje dohvat

Bafer linije ima 640 reči i puni se u rafalima po 8, što je oko 23 µs — duže od
horizontalnog zatamnjenja (6 µs). Dohvat zato prelazi u sledeću liniju, a `sdram_ctrl`
uzima `LINE_Y` **neprekidno**, ne pamti ga na početku dohvata. Ako se `LINE_Y` promeni
usred dohvata, druga polovina bafera se napuni iz pogrešne vrste i slika se cepa.

Zato je vrsta `LINE_Y = (curY + 1) / 2`, a ne `curY/2 + 1`:

| `curY` | `curY/2 + 1` | `(curY+1)/2` |
|---|---|---|
| 2k+1 (zahtev se šalje ovde) | k+1 | k+1 |
| 2k+2 (dohvat još traje) | k+2 ✗ | k+1 ✓ |

Tako `LINE_Y` ostaje isti kroz ceo dohvat. Granica vidljivog dela je zato poređenje
`YN < 600` (umesto `< 300`), jer se poredi `curY+1`, a vrsta je `YN[9..1]`.

Dohvat i prikaz dele isti bafer, pa upis „trči ispred“ čitanja: upis kreće 6 µs ranije i
napreduje oko 28 reči/µs, a čitanje oko 20 reči/µs i staje na 400, pa upis ostaje ispred
sa rezervom od preko 10 µs.

### Ostalo što je moralo da se namesti
- adresa piksela se traži **1 takt unapred** (`PIX_X = (curX + 1) / 2`): put boje ima tri
  registra (`ADR_REG`, bafer linije, `BOJA`), koliko i put sinhronizacije, pa je pomeraj
  tačno 1 piksel ekrana
- izlazi (HS, VS, boja) su registrovani taktom piksela (tri puta, kao i boja)
- na kraju kadra bi ispala vrsta veća od 299, pa se sve preko toga svodi na 0
- bafer linije `Memory/line_buf` čita adresu **taktom VGA bloka** (`address_reg_b`
  je `"CLOCK1"`); dok je bio `"CLOCK0"`, adresa iz takta od 40 MHz se uzorkovala taktom
  od 50 MHz, pa su se povremeno prikazivali pogrešni pikseli (titranje slike)

Provereno u simulaciji: linija 26 µs (sinhro 2,98 µs), kadar 17,3 ms (sinhro 130 µs),
666 linija po kadru, 333 zahteva za vrstom, `LINE_Y` ide od 0 do 299.

Nedovršeni `GPU/GPU.bdf` je izbačen iz projekta: izlaz `X` iz vremenskog generatora nije
bio povezan, oba bafera linije su imala isti signal upisa, komparator za `finished` je
imao nepovezane izlaze, a crvena i plava su bile zamenjene. Posao koji je trebalo da radi
(čitanje SDRAM-a i bafer linije) ionako radi `sdram_ctrl`.

## 15. Prekidi: `Components/irq_ctrl.bdf`

Zastavice prekida stoje van `mem_top`, jer njihovi izvori nisu u memoriji:

| Bit | Izvor |
|---|---|
| 0 | stigao kod sa tastature (`KB_INTR` iz `kb_ps2`) |
| 1 | počela nova slika (`VSYNC` iz VGA bloka) |

Zastavica se postavlja na uzlaznu ivicu događaja i stoji dok je program ne obriše upisom
u `IRQ_CLEAR` (`0x0800002C`). `IRQ` je jedinica dok postoji bar jedna zastavica, pa ga
procesor vidi na kraju svake instrukcije. Prekidna rutina je na adresi `0x10`, a dozvola
prekida se uključuje sa `csrsi mstatus,8`.

## 16. Tastatura: `KbController/kb_ps2.bdf` i `kb_keys.bdf`

`kb_ps2` (ranije `CodeDetector`) prima PS/2 kodove i javlja ih impulsom `INTR`, a
`kb_keys` od njih pravi bit-mapu pritisnutih tastera:

| Bit | Taster | Kod |
|---|---|---|
| 7 | Z (okretanje) | `0x1A` |
| 6 | strelica gore (odlaganje) | `0x75` |
| 5 | strelica levo | `0x6B` |
| 4 | strelica dole | `0x72` |
| 3 | strelica desno | `0x74` |
| 2 | T (sledeća tema) | `0x2C` |
| 1 | razmak (trenutni pad) | `0x29` |
| 0 | P (pauza) | `0x4D` |

Kod `0xE0` najavljuje strelicu i preskoči se, a `0xF0` najavljuje otpuštanje, pa se
zastavica tastera koji stigne posle njega briše. Cela bit-mapa se čita sa adrese
`PS2_KEYS_LO` (`0x08000020`).

## 17. Miš: `MouseController/mouse_ps2.bdf`

Miš se po uključenju ne javlja sam, pa mu kontroler prvo pošalje naredbu `0xF4`
(„šalji podatke“):

1. čeka ~160 ms (`ms_dly`, modul 8 000 000) da miš završi svoju proveru; taj brojač
   broji samo dok reset nije aktivan, pa se posle svakog reseta odbroji punih 160 ms,
2. drži liniju takta na nuli 100 µs (`ms_wait`, najava slanja),
3. spušta liniju podataka (start bit) i pušta takt, pa miš sam daje takt,
4. na svaku silaznu ivicu izbacuje sledeći bit — start, 8 bita, parnost, stop i
   potvrda su 11 ivica, koliko broji `ms_txcnt` (modul 12, `cout` na 11); taj brojač
   ima sinhrono brisanje vezano na reset, pa se naredba ponovo pošalje na svaki reset
   (bez toga bi brojač ostao na 11 i druga prijava miša ne bi bila moguća),
5. posle toga samo prima pakete od tri bajta (`ms_cnt11` broji 11 bita po bajtu).

U paketu su tasteri i znaci pomeraja (bajt 0, treći bit je uvek 1 i po njemu se paketi
poravnavaju), pomeraj po x (bajt 1) i po y (bajt 2). Linije PS/2 su tipa „otvoreni
kolektor“: kontroler ih samo spušta na nulu, a na glavnoj šemi su `OPNDRN` baferi.

### Nadzor mirovanja (`ms_idle`)

Brojač bita i stanje paketa se sami ne bi oporavili ako se izgubi bit ili bajt — a to se
dešava u dva sasvim obična slučaja: miš na naredbu `0xF4` odgovara bajtom `0xFA`, koji
nije deo paketa, a pritisak na KEY0 nakratko spusti liniju takta i prekine bajt koji je
u toku. Zato je dodat brojač `ms_idle` (modul 262 144):

- briše se (`sclr`) kad god je linija takta na nuli, a broji dok je u jedinici,
- `cnt_en` se isključi kad stigne do kraja, pa `cout` (`IDLE_LONG`) stoji dok se
  magistrala ne pokrene — magistrala miruje duže od **5,24 ms**,
- dok `IDLE_LONG` stoji i brojač bita nije na nuli, `ms_cnt11` se vrti punim taktom dok
  ne dođe do nule (ponovno poravnanje bita; `ms_rx` se pri tom ne pomera),
- `IDLE_LONG` takođe drži `ms_pstate` na nuli, pa sledeći bajt uvek ide kao prvi bajt
  paketa.

Najduža pauza unutar jednog bajta je pola periode PS/2 takta (najviše 50 µs), a tri
bajta paketa stižu jedan za drugim, pa prag od 5,24 ms ne može da pogodi sredinu paketa.

### Izlaz

Izlaz ide na `PS2_KEYS_HI` (`0x08000024`): bitovi 2..0 su tasteri, 10..3 pomeraj po x,
18..11 pomeraj po y, a **bit 19 menja vrednost na svaki primljen paket** (`PKT_TOGGLE`).
Kontroler pamti samo poslednji pomeraj, pa bez tog bita program ne bi mogao da razlikuje
„miš miruje“ od „miš se kreće istom brzinom“ — kursor bi stao čim se pomeraj ponovi.

### Jedan PS/2 priključak: prekidač `SW9`

Ploča DE0-CV ima samo jedan PS/2 priključak. Drugi par linija (`PS2_CLK2`/`PS2_DAT2`)
postoji na FPGA, ali do njega se dolazi samo PS/2 Y-razdelnikom. Zato kontroler miša
sada radi na **prvom paru** (`PS2_CLK`/`PS2_DAT`), zajedno sa dekoderom tastature, a
klizni prekidač `SW9` bira koji je uređaj utaknut:

| `SW9` | `MRST_N = RST_N · SW9` | `KB_INTR_G = KB_INTR · /SW9` |
|---|---|---|
| 0 (tastatura) | miš je u resetu — `PS2_CLK_LOW` i `PS2_DAT_LOW` su nule, pa su linije puštene | tastatura radi |
| 1 (miš) | miš radi | dekoder tastature ne menja bit-mapu ni zastavicu prekida |

Pinovi `PS2_CLK` i `PS2_DAT` su zato postali **bidirekcioni**, a kontroler ih spušta na
nulu preko `OPNDRN` bafera, kao što je ranije radio sa drugim parom. Izabrani režim se
vidi na `LEDR6`.

Ako se nabavi Y-razdelnik i želi istovremeni rad oba uređaja, dovoljno je u `Tetris.bdf`
vratiti ulaze i `OPNDRN` izlaze kontrolera miša na `PS2_CLK2`/`PS2_DAT2` i izbaciti
`SW9` sa kapijama.

### Provera na ploči

`LEDR9` = PLL zaključan, `LEDR8` = `TX_OK` (miš je izgenerisao takt i primio `0xF4`),
`LEDR7` = `PKT_TOGGLE` (menja se na svaki paket), `LEDR6` = izabrani režim,
`LEDR2..0` = tasteri miša. Ako `LEDR8` ostane ugašen, miš nije dao nijednu ivicu takta
— nije PS/2 uređaj, nije na tom paru ili je `SW9` u pogrešnom položaju.



## 18. Program igre: `TetrisProgram/`

Program je u C-u i prevodi se sa `build.sh`, koji rezultat upisuje u `Memory/rom_init.mif`.
Pošto procesor nema pristup bajtu i polureči, ni množenje i deljenje:
- svi tipovi su 32-bitni (`common.h`), pa nema `lb`/`sb`,
- množenja i deljenja nema u instrukcijama, pa se deljenje radi funkcijom `udivmod`
  (`mathutil.c`, pomeranje i oduzimanje), a množenje konstantama prevodilac sam razlaže
  na pomeranja i sabiranja,
- `build.sh` posle prevođenja pregleda listing i prekida ako naiđe na instrukciju koju
  procesor nema.

Raspored: `board.c` (polje, oblici, brisanje redova), `gfx.c` (crtanje preko periferije),
`input.c` (bit-mapa tastera), `mouse.c` (tasteri i sabiranje pomeraja),
`theme.c` (četiri teme boja), `score.c` (poeni na HEX displeju), `game.c` (tok igre),
`main.c` (pokretanje i prekidna rutina).

Slika se crta u bafer koji se ne prikazuje, pa se na kraju kadra bafere zamene
(`VGA_CTRL = 1`) i sačeka vertikalna sinhronizacija.

## 19. Završno spajanje i ispravke

Posle spajanja svih blokova na ploči ispravljeno je sledeće. Sve izmene su namerno
male — nijedna šema nije prerađivana, menjane su vrednosti konstanti, jedna veza i
dodat je jedan brojač.

| Šta | Gde | Zašto |
|---|---|---|
| `address_reg_b` iz `"CLOCK0"` u `"CLOCK1"` | `Memory/line_buf.vhd` | adresa piksela dolazi iz takta od 40 MHz, a uzorkovala se taktom od 50 MHz — povremeno pogrešan piksel (titranje slike) |
| `LINE_Y = (curY+1)/2` umesto `curY/2 + 1`, granica 600 umesto 300 | `GPU/vga.bdf` | broj vrste se menjao usred dohvata iz SDRAM-a, pa se druga polovina vrste punila iz sledeće (odeljak 14) |
| pomeraj adrese piksela sa +2 na +1 | `GPU/vga.bdf` | put boje ima tri registra, koliko i put sinhronizacije; slika je bila pomerena za jedan piksel ekrana |
| `phase_shift1` sa `0 ps` na `-3000 ps` | `Memory/sys_pll` | takt koji ide na SDRAM mora da kasni −3 ns za sistemskim, kako je i opisano u odeljku 10; bez toga ne važe ograničenja iz `tetris.sdc` |
| novi brojač `ms_idle` i nadzor mirovanja | `MouseController/mouse_ps2.bdf` | bez njega se poravnanje bita i paketa nikad ne oporavi posle `0xFA`, posle reseta tasterom KEY0 ili posle izgubljenog bita (odeljak 17) |
| `PKT_TOGGLE` (bit 19) umesto brojanja bajtova | `mouse_ps2` → `PS2_KEYS_HI` | program prepoznaje nov paket; ranije se kursor zaustavljao kada se pomeraj ponovi |
| čekanje po uključenju sa 100 ms na 160 ms, i broji samo van reseta | `MouseController/ms_dly` | naredba `0xF4` je mogla da stigne pre nego što miš završi svoju proveru |
| `ms_cnt12` → `ms_txcnt` (isti brojač, ali sa `sclr`) | `mouse_ps2` | brojač je posle prve naredbe ostajao na 11, pa se `0xF4` više nikada nije slala — miš utaknut posle paljenja ploče nije mogao da se prijavi |
| miš prebacen na prvi PS/2 par, `SW9` bira uređaj | `Tetris.bdf` | ploča ima jedan priključak, a drugi par linija traži Y-razdelnik; bez razdelnika kontroler miša nije video ništa |
| `CODE[7..0]` je dobio vezu do izlaznog pina | `KbController/kb_ps2.bdf` | flip-flopovi voze mreže `CODE0`…`CODE7`, a izlazni pin je bus `CODE[7..0]` — veza nije bila nacrtana |

Preimenovani blokovi (samo imena, sadržaj je isti): `vga_kolege` → `vga`,
`Controller` → `vga_timing`, `CodeDetector` → `kb_ps2`.

Izbačeni fajlovi koji nisu bili u projektu: `GPU/GPU.bdf`, `KbController/CodeInterpeter.bdf`,
`CPU/data_ram.*`, `CPU/instruction_rom.*`, `CPU/instruction.mif`, `Components/init_rom.qip`,
`TetrisProgram/main_test4.c`.

Izmene u programu igre: `mouse.c` sabira pomeraj samo kada stigne nov paket i ne gleda
tastere dok miš ne pošalje prvi ceo paket, da odgovor `0xFA` ne bi izgledao kao
pritisnut taster. Funkcija `mouseDrawCursor` postoji, ali se ne poziva.
